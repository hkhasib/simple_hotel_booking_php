<footer>
<center><h4>Copyright: Hotel Booking Inc.</h4></center>

    </footer>
    </html>
